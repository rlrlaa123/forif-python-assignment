
howLong = 0

print "Enter name: "
name = str(raw_input())

print "Enter age: "
age = int(raw_input())

while age < 100:
    howLong += 1
    age += 1

print name, " will become 100 in: ", (2016 + howLong)

#no errors