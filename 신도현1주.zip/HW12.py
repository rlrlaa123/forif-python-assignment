print "Enter an alphabet: "

alphabet = str(raw_input())

if len(alphabet) == 1:
    if alphabet in ('a', 'e', 'i', 'o', 'u'):
        print "You entered a vowel"
    else:
        print "You entered a consonant"

else:
    print "Please restart and enter only one alphabet."

#no errors