def deterFirst():
    if firNum % 2 == 0:
        print "Your first number is even."
    else:
        print "Your first number is odd."

def deterSec():
    if secNum % 2 == 0:
        print "Your second number is even."
    else:
        print "Your second number is odd."


print "Enter first number: "
firNum = int(raw_input())

print "Enter second number: "
secNum = int(raw_input())

deterFirst()
deterSec()

#No errors