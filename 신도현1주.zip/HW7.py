# numbers that are divisible by 7 and 5 from 1500 to 2700

num = []

for i in range(1500, 2700):
    if i % 5 == 0:
        if i % 7 ==0:
            num.append(i)
            i += 1

print num

# no errors