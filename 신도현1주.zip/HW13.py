coke = 1500
juice = 1200
energy_drink = 2000
earnings = 0
dict = {'Coke': 0, 'Juice': 0, 'EnergyDrink': 0}

print "What would you like to drink?\nStart all orders with a capital letter: "
print "Menu: Coke, Juice, EnergyDrink"
print "Type n to stop ordering"

while earnings <= 10000:
    order = str(raw_input())
    if order == 'Coke':
        earnings += coke
        dict['Coke'] += 1
    elif order == 'Juice':
        earnings += juice
        dict['Juice'] += 1
    elif order == 'EnergyDrink':
        earnings += energy_drink
        dict['EnergyDrink'] += 1
    elif order == 'n':
        break
    else:
        print "Wrong order, try again."
    print "What else would you like?"

print dict

#No errors