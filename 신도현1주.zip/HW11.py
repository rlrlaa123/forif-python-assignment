
print "Enter iteration: "
n = int(raw_input())

a,b = 1,1
print "0\n1"
for i in range(n-1):
    a,b = b,a+b
    if a > 50:
        print "You have exceeded the limit"
        break
    else:
        print a


#trouble starting with 0,1
#no errors

