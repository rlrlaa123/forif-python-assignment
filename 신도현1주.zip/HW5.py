#find out how many vars have the same end and beginning

a = ["abc", "xyz", "aba", "1221"]

one = a[0]
two = a[1]
three = a[2]
four = a[3]
answer = []

if one.startswith('a') and one.endswith('a'):
    answer.append(one)
if two.startswith('x') and two.endswith('x'):
    answer.append(two)
if three.startswith('a') and three.endswith('a'):
    answer.append(three)
if four.startswith('1') and four.endswith('1'):
    answer.append(four)

print "The number of variables that have the same beginning and end is ", len(answer)

#works but code is filthy need to find easier way

