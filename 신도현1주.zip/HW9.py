def right_up(i, t=0):
    if i == 0:
        return 0
    else:
        print '*' * ( t * 2 + 1 )
        return right_up( i - 1, t + 1 )


def upside_down(i, t=0):
    if i == 0:
        return 0
    else:
        print '*' * ( i * 2 - 1 )
        return upside_down( i - 1, t + 1 )

right_up(4)
upside_down(3)

# no error