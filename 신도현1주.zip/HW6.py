dup_list = [10,20,30,20,10,50,60,40,80,50,40]

newList = []

for i in dup_list:
    if i not in newList:
        newList.append(i)

newList.sort()

print newList

#no errors

