import random

humanGuess = 0

target_num = random.randint(1,10)

print 'I am thinking of a number between 1 and 10.'

while humanGuess < 6:
    print 'Take a guess'

    guess = raw_input()
    guess = int(guess)

    humanGuess += 1

    if guess < target_num:
        print "Your guess is too low."

    elif guess > target_num:
        print "Your guess is too high"

    elif guess == target_num:
        break

if guess == target_num:
    humanGuess = str(humanGuess)
    print "You guessed the number in " + humanGuess + "guesses!"

if guess != target_num:
    target_num = str(target_num)
    print "Wrong. The number I was thinking of is " + target_num

#no errors