#add and print sum in list

sum_list= [1,2,-20]

total = sum(sum_list)

print total

# no errors, what about typing?